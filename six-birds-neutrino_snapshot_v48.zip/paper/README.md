# Paper Scaffold

Compile from inside `paper/`:

- `latexmk -pdf -interaction=nonstopmode main.tex`

If `latexmk` is unavailable, use fallback steps:

1. `pdflatex -interaction=nonstopmode main.tex`
2. `bibtex main`
3. `pdflatex -interaction=nonstopmode main.tex`
4. `pdflatex -interaction=nonstopmode main.tex`

Figures and tables are placeholders for later tickets.
